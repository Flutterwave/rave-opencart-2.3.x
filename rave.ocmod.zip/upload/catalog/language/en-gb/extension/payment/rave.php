<?php
// Place Holder Text
$_['text_title'] = "Rave Payment Gateway";
$_['text_testmode'] = 'Warning: The payment gateway is in \'Sandbox(test) Mode\'. Use a test card.';
